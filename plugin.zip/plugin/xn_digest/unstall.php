<?php

/*
	Xiuno BBS 4.0 插件实例：精华主题卸载
	admin/plugin-unstall-xn_digest.htm
*/

!defined('DEBUG') AND exit('Forbidden');

?>