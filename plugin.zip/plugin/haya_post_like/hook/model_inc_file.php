<?php
exit;

APP_PATH.'plugin/haya_post_like/model/haya_post_like.func.php',


?>