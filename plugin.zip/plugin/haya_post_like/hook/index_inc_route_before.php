<?php
exit;

$haya_post_like_config = setting_get('haya_post_like');

?>