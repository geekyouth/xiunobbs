<?php exit;

$menu['setting']['tab'] += array (			
	'extend'=>array('url'=>url('setting-extend'), 'text'=>lang('admin_setting_extend'))
);

?>