 <?php exit;
 message(0, lang('create_thread_sucessfully').$_SESSION['sg_group_message']);
 ?>