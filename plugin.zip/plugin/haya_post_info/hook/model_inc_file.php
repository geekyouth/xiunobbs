<?php
exit;

APP_PATH.'plugin/haya_post_info/model/haya_post_info.func.php',


?>