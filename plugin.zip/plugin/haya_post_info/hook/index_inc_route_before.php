<?php
exit;

$haya_post_info_config = setting_get('haya_post_info');

?>