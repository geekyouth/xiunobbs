<?php exit;
$post['is_secret'] = $arr['is_secret'];