include _include(APP_PATH.'plugin/huux_notice/model/notice.func.php');
