<?php
return [
		'APP_HOST'    => 'http://loc.xiunobbs.com',
		'OAPI_HOST'   => 'https://oapi.dingtalk.com',
		'CORPID'      => 'dingde55314a8e20f3f6',
		'SECRET'      => 'L0k5CtQscvusMrbC4aLoVUv_W7VHC9AnYGH0roxD3w6dFlB8DNquukbYMcstqZ2R',
		'AGENTID'     => '172750047',
		'DEFAULT_PWD' => '123456'
];