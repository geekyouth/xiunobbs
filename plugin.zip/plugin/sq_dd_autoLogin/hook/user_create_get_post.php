// 当来自dd_login的访问时，开放其用户注册
$create_on = param('create_on');
$conf['user_create_on'] = $create_on;