<?php

/*
	Xiuno BBS 4.0 插件：敏感词过滤卸载
	admin/plugin-unstall-qt_sensitive_word.htm
*/

!defined('DEBUG') AND exit('Forbidden');

?>