<?php exit;
case 'content': include _include(APP_PATH . './plugin/well_cms/route/content.php'); break;
case 'list': include _include(APP_PATH . './plugin/well_cms/route/list.php'); break;
case 'channel': include _include(APP_PATH . './plugin/well_cms/route/channel.php'); break;
case 'tag': include _include(APP_PATH . './plugin/well_cms/route/tag.php'); break;
?>