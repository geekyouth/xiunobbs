<?php exit;
// 过滤发帖页非bbs版块 栏目导航数据
$forumlist = well_get_bbs_list($forumlist);
?>