<?php exit;
well_set_cookie_forumarr('BBS');
?>