<?php exit;
    $pagesize = 15;
?>