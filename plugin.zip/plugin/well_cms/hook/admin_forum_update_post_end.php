<?php exit;
well_cms_delete_cache();
?>