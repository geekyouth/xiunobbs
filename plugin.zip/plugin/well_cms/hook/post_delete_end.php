<?php exit;
// 清理wellcms缓存数据
well_cms_delete_cache();
?>