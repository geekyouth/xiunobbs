<?php exit;
    // 更新token 单点登录
	user__update($uid, array('well_token'=>$token));
?>