<?php exit;
// 接收编辑版块数据入库
$arr['well_type'] = $well_type;
$arr['well_nav_display'] = $well_nav_display;
$arr['well_model'] = $well_model;
$arr['well_forum_type'] = $well_forum_type;
$arr['well_fup'] = $well_fup;
$arr['well_tpl'] = $well_tpl;
$arr['well_tpl_class'] = $well_tpl_class;
$arr['well_tpl_show'] = $well_tpl_show;
$arr['well_comment'] = $well_comment;
$arr['well_display'] = $well_display;
$arr['well_news'] = $well_news;
$arr['well_headlines'] = $well_headlines;
$arr['well_channel_display'] = $well_channel_display;
$arr['well_channel_news'] = $well_channel_news;
$arr['well_channel_headlines'] = $well_channel_headlines;
$arr['well_channel_slides'] = $well_channel_slides;
$arr['well_channel_headline'] = $well_channel_headline;
$arr['well_channel_guide'] = $well_channel_guide;
$arr['well_channel_recommend'] = $well_channel_recommend;
$arr['well_list_news'] = $well_list_news;
$arr['well_list_headlines'] = $well_list_headlines;
$arr['well_list_recommends'] = $well_list_recommends;

?>