if(IS_MOBILE) {
	// $show_search = 2; // 头部不显示东西
	include _include(APP_PATH . SQ_MOBILE_PATH . '/view/htm/user_login.htm');
	return;
}