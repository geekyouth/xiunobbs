<?php exit;
// 和post关联成功后删除session里面的文件信息
$_SESSION['tmp_files_sq'] = array(); // 清空session