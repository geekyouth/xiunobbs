<?php exit;
$thread['is_secret'] = $arr['is_secret'];