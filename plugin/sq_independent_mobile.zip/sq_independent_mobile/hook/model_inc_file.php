    APP_PATH . 'plugin/sq_independent_mobile/model/sq_function.func.php',
    APP_PATH . 'plugin/sq_independent_mobile/model/plugin.func.php',
    APP_PATH . 'extends/Log.class.php',