if(IS_MOBILE) {
	// $show_search = 2;
	include _include(APP_PATH . SQ_MOBILE_PATH . '/view/htm/my_password.htm');
	return;
}