if(IS_MOBILE) {

    include _include(APP_PATH . SQ_MOBILE_PATH . 'view/other_plugin/xn_mypost/user_post.htm');

    return;
}