if(IS_MOBILE) {
	// $show_search = 2;
	include _include(APP_PATH . SQ_MOBILE_PATH . '/view/other_plugin/xn_digest/my_digest.htm');
	return;
}